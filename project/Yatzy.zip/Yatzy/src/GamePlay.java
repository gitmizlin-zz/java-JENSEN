import javax.swing.*;
import java.util.ArrayList;

public class GamePlay {
    public boolean gameEnd = false;
    Board board;

    GamePlay() {

        board = new Board();


    }
}
